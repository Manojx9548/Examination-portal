import React from 'react'

function ImageSlider() {
  return (
    <div>
        <img src="https://img.freepik.com/free-vector/illustration-university-graduates_53876-28466.jpg?size=626&ext=jpg&ga=GA1.1.447109046.1720588547&semt=sph" alt="" className='h-30 w-full' />
    </div>
  )
}

export default ImageSlider